﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MatrixProject
{
    class Program
    {   

        static void generateMatrix(int []arr,int n)
        {
            int sum = n;
               
            for (int i = 0; i < arr.Length; i++)
            {
                if (i >= n) { 
                    Console.WriteLine();
                    n += sum;
                }
                Console.Write(arr[i] + "\t");
            }
        }
        
        static void Main(string[] args)
        {
            Console.Write("Enter the value of n: ");                 //Added to this to make it easy to understand and moved from outside main to inside and removed static keyword
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n * n];
            int currentPosition = 0;
            
            for (int i = 0; i < arr.Length; i++)
                arr[i] = 0;
            arr[arr.Length - n] = 1;
            currentPosition = arr.Length - n;
            Console.WriteLine();
            generateMatrix(arr, n);
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("\n8.Up\t2.Down\t4.Left\t6.Right\t 1.Exit");       // made it in one line with one tab, so that it don't take much space.
                Console.WriteLine();
                Console.WriteLine("Enter Your Option : ");
                int opt = int.Parse(Console.ReadLine());
                int sum = n, a=0, b=0;                                              // removed cp and n1 coz they are in no use.
                if (opt == 1)                                                       // exit number made from 5 to 1.
                    System.Environment.Exit(0);
                switch (opt)
                {
                    case 8:
                        int data = Math.Abs(n - currentPosition);
                        if (currentPosition > 0 || currentPosition>n)
                        {
                            a = currentPosition - n;
                            b = a + n;
                            arr[a] = 1;
                            arr[b] = 0;
                            currentPosition = a;
                            generateMatrix(arr, n);
                        }
                        else
                            Console.WriteLine("We can't Move");               
                        break;

                    case 2:
                        if (currentPosition >= 0 && currentPosition < arr.Length - n)
                        {
                            a = currentPosition + n;
                            b = a - n;
                            arr[a] = 1;
                            arr[b] = 0;
                            currentPosition = a;
                            generateMatrix(arr, n);
                        }
                        else
                        {
                            Console.WriteLine("We can't Move");
                            generateMatrix(arr, n);
                        }
                        break;

                    case 6:
                        if(currentPosition>0 || currentPosition < arr.Length)
                        {
                            a = currentPosition + 1;
                            if (a % n == 0)
                            {
                                Console.WriteLine("We can't Move");
                                b = a;
                                arr[a] = 1;
                                arr[b] = 0;
                                generateMatrix(arr, n);
                                break;
                            }
                            else
                            {
                                b = a - 1;
                                arr[a] = 1;
                                arr[b] = 0;
                                currentPosition = a;
                                generateMatrix(arr, n);
                            }
                        }
                        else
                        { 
                            Console.WriteLine("We can't Move");
                        }
                        break;

                    case 4:
                        if (currentPosition > 0 || currentPosition < arr.Length)
                        {
                            a = currentPosition - 1;
                            Console.WriteLine("Current Position : " + currentPosition);
                            if (currentPosition % n == 0)
                            {
                                
                                Console.WriteLine("We can't Move");
                                b = a;
                                arr[a] = 1;
                                arr[b] = 0;
                                generateMatrix(arr, n);
                                break;
                            }
                            else
                            {
                                b = a + 1;
                                arr[a] = 1;
                                arr[b] = 0;
                                currentPosition = a;
                                generateMatrix(arr, n);
                            }
                            }
                       
                        else
                        {
                            Console.WriteLine("We can't Move");
                        }
                        break;
                }
            }
            
            
        }
    }
}
